# Chopka Client — starter project

A starter Fabric client mod for Minecraft Java 1.21.4 / Java 21.

## Included
- Right Shift opens the Chopka Client screen.
- Dark panel with neon teal accents and lightweight particle decoration.
- UI display-nickname field (cosmetic only; does not change the authenticated account or server name).
- Toggles for glow, particles, FPS HUD, and coordinates HUD.
- HUD renderer is registered during client initialization.
- Menu is opened with Right Shift; the key can be rebound in Minecraft Controls.
- Optional coordinates HUD hook (disabled by default).

## Build
1. Install JDK 21.
2. Install Gradle or use a Gradle wrapper generated for your environment.
3. Run `gradle build`.
4. The JAR is in `build/libs/`.

## Notes
This is a source starter, not a prebuilt/verified JAR. API signatures may need small adjustments depending on the exact Fabric API build. Persistent settings and real account switching are not implemented. Account switching must use legitimate Minecraft authentication; changing the display nickname in this screen is UI-only.
